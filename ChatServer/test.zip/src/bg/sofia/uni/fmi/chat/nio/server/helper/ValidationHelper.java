package bg.sofia.uni.fmi.chat.nio.server.helper;

public class ValidationHelper {
    public static void validateNotNull(Object obj, String errMessage) {
        if (obj == null) {
            throw new IllegalArgumentException(errMessage);
        }
    }

    public static void validateEmptyString(String str, String errMessage) {
        if (str.length() == 0) {
            throw new IllegalArgumentException(errMessage);
        }
    }
}
