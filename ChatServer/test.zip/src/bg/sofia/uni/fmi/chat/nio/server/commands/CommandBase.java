package bg.sofia.uni.fmi.chat.nio.server.commands;

import bg.sofia.uni.fmi.chat.nio.server.commands.contracts.Command;

import java.nio.channels.SocketChannel;

import static bg.sofia.uni.fmi.chat.nio.server.GlobalConstants.*;
import static bg.sofia.uni.fmi.chat.nio.server.helper.ValidationHelper.validateEmptyString;
import static bg.sofia.uni.fmi.chat.nio.server.helper.ValidationHelper.validateNotNull;

public abstract class CommandBase implements Command {
    private SocketChannel socket;
    private String username;

    public CommandBase(String username, SocketChannel socket) {
        setUsername(username);
        setSocket(socket);
    }

    public SocketChannel getSocket() {
        return socket;
    }

    public String getUsername() {
        return username;
    }

    private void setUsername(String username) {
        validateNotNull(username, ERROR_MESSAGE_NULL_VALUE);
        validateEmptyString(username, ERROR_MESSAGE_INVALID_USERNAME);
        this.username = username;
    }

    private void setSocket(SocketChannel socket) {
        validateNotNull(socket, ERROR_MESSAGE_NULL_VALUE);
        this.socket = socket;
    }
}
