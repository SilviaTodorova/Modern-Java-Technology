package bg.sofia.uni.fmi.chat.server.commands.enums;

public enum CommandType {
    SEND,
    SENDALL,
    LISTUSERS,
    DISCONNECT
}
