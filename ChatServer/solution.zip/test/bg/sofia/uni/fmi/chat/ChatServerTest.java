package bg.sofia.uni.fmi.chat;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import bg.sofia.uni.fmi.chat.client.ChatClient;
import bg.sofia.uni.fmi.chat.server.ChatServer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class ChatServerTest {

    private static ChatServer chatServer;
    private static Thread serverStarterThread;

    @Before
    public void setup() {
        serverStarterThread = new Thread() {

            public void run() {
                chatServer = new ChatServer();
                chatServer.run();
            }
        };

        serverStarterThread.start();
    }

    @Test
    public void testServer() throws UnsupportedEncodingException {
        ChatClient chatClient = Mockito.mock(ChatClient.class);
        Mockito.doNothing().when(chatClient).connect("ivan");
    }
}

