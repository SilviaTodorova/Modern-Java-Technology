package bg.sofia.uni.fmi.chat.net;

import org.junit.Test;

public class ChatClientTest {
    @Test
    public void sendRequest() {
    }
}