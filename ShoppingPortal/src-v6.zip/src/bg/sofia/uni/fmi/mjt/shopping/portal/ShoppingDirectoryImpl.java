package bg.sofia.uni.fmi.mjt.shopping.portal;

import bg.sofia.uni.fmi.mjt.shopping.portal.comparators.PriceComparator;
import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.NoOfferFoundException;
import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.OfferAlreadySubmittedException;
import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.ProductNotFoundException;
import bg.sofia.uni.fmi.mjt.shopping.portal.offer.Offer;

import java.time.LocalDate;
import java.util.*;

public class ShoppingDirectoryImpl implements ShoppingDirectory {
    private static final int DAYS = 30;
    private final Map<String, SortedSet<Offer>> offers;

    public ShoppingDirectoryImpl() {
        this.offers = new HashMap<>();
    }

    /**
     * Returns a collection of offers submitted in the last 30 days
     * for the product with name @productName sorted by total price
     * in ascending order.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Collection<Offer> findAllOffers(String productName) throws ProductNotFoundException {
        if (productName == null) {
            throw new IllegalArgumentException();
        }

        if (!offers.containsKey(productName)) {
            throw new ProductNotFoundException();
        }

        // Offers must be sorted by price in ascending order
        Collection<Offer> offers = this.offers.get(productName);
        Set<Offer> submittedOffersInLastNDays = new LinkedHashSet<>();

        // Filter these offers which aren't submitted in the last N days
        for (Offer offer : offers) {
            if (offer.isSubmittedInLastNDays(DAYS)) {
                submittedOffersInLastNDays.add(offer);
            }
        }

        return submittedOffersInLastNDays;
    }

    /**
     * Returns the most favorable offer for the product with name @productName
     * submitted in the last 30 days - the one with lowest total price.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws NoOfferFoundException    if there is no offer submitted in the last 30
     *                                  days for the product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Offer findBestOffer(String productName) throws ProductNotFoundException, NoOfferFoundException {
        Collection<Offer> offersSubmittedInLastNDays = this.findAllOffers(productName);

        if (offersSubmittedInLastNDays.size() == 0) {
            throw new NoOfferFoundException();
        }

        return offersSubmittedInLastNDays.iterator().next();
    }

    /**
     * Returns a collection of price statistics for the product with name @productName
     * sorted by date in descending order.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Collection<PriceStatistic> collectProductStatistics(String productName) throws ProductNotFoundException {
        if (productName == null) {
            throw new IllegalArgumentException();
        }

        if (!offers.containsKey(productName)) {
            throw new ProductNotFoundException();
        }

        // Get all offers by productName
        Collection<Offer> offers = this.offers.get(productName);

        // Get all dates
        Set<LocalDate> dates = distinctDates(offers);

        Set<PriceStatistic> statistics = new TreeSet<>();

        for (LocalDate date : dates) {
            Collection<Offer> offersFilteredByDate = filterByDate(date, offers);
            offers.removeAll(offersFilteredByDate);

            int countOffers = offersFilteredByDate.size();
            double sumTotalPrices = sumTotalPrices(offersFilteredByDate);
            double averagePrice = (double) sumTotalPrices / countOffers;

            Offer offerWithLowerPrice = offersFilteredByDate.iterator().next();
            double lowerPrice = offerWithLowerPrice.getTotalPrice();

            PriceStatistic stat = new PriceStatistic(date, averagePrice, lowerPrice);
            statistics.add(stat);
        }

        return statistics;
    }

    private static Set<LocalDate> distinctDates(Collection<Offer> offers) {
        Set<LocalDate> dates = new HashSet<>();
        for (Offer offer : offers) {
            LocalDate date = offer.getDate();
            dates.add(date);
        }
        return dates;
    }

    private static double sumTotalPrices(Collection<Offer> offers) {
        double sumTotalPrices = 0;

        for (Offer offer : offers) {
            sumTotalPrices += offer.getTotalPrice();
        }
        return sumTotalPrices;
    }

    private static Collection<Offer> filterByDate(LocalDate date, Collection<Offer> offers) {
        Set<Offer> filtered = new TreeSet<>(new PriceComparator());

        for (Offer offer : offers) {
            LocalDate offerDate = offer.getDate();
            if (offerDate.equals(date)) {
                filtered.add(offer);
            }
        }
        return filtered;
    }

    /**
     * Submits a new offer.
     *
     * @throws OfferAlreadySubmittedException if an identical @offer has already been submitted
     * @throws IllegalArgumentException       if @offer is null
     */
    @Override

    public void submitOffer(Offer offer) throws OfferAlreadySubmittedException {
        if (offer == null) {
            throw new IllegalArgumentException();
        }

        String productName = offer.getProductName();
        SortedSet<Offer> offersForProduct = new TreeSet<>(new PriceComparator());
        if (this.offers.containsKey(productName)) {
            offersForProduct = this.offers.get(productName);
            if (offersForProduct.contains(offer)) {
                throw new OfferAlreadySubmittedException();
            }
        }

        offersForProduct.add(offer);
        this.offers.put(productName, offersForProduct);
    }
}
