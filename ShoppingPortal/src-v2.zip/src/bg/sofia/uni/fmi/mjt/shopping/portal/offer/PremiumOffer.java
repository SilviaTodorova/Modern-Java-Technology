package bg.sofia.uni.fmi.mjt.shopping.portal.offer;

import java.time.LocalDate;
import java.util.Objects;

public class PremiumOffer extends AbstractOffer {
    private static final double SCALE = Math.pow(10, 2);

    private double discount;

    public PremiumOffer(String productName, LocalDate date, String description, double price, double shippingPrice, double discount) {
        super(productName, date, description, price, shippingPrice);
        this.setDiscount(discount);
    }

    private void setDiscount(double discount) {
        if (discount < 0 || discount > 100) {
            throw new IllegalArgumentException();
        }

        this.discount = Math.round(discount * SCALE) / SCALE;
    }

    @Override
    public double getTotalPrice() {
        double totalPrice = super.getTotalPrice();
        double percent = this.discount / 100;
        double discountOfPrice = totalPrice * percent;
        return totalPrice - discountOfPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AbstractOffer other = (PremiumOffer) o;
        String productName = this.getProductName();
        String productNameLowerCase = productName.toLowerCase();

        String otherProductName = other.getProductName();
        String otherProductNameLowerCase = otherProductName.toLowerCase();

        boolean equalsProductName = Objects.equals(productNameLowerCase, otherProductNameLowerCase);
        boolean equalsDate = Objects.equals(this.getDate(), other.getDate());
        boolean equalsTotal = Objects.equals(this.getTotalPrice(), other.getTotalPrice());

        return equalsProductName && equalsDate && equalsTotal;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getProductName(), this.getDate(), this.getTotalPrice());
    }

    @Override
    public int compareTo(Object o) {
        if (this.equals(o)) {
            return 0;
        }

        AbstractOffer other = (PremiumOffer) o;

        // Descending order
        double difference = this.getDate().compareTo(other.getDate());
        if (difference < 0) {
            return -1;
        } else {
            return 1;
        }
    }
}
