package bg.sofia.uni.fmi.mjt.shopping.portal;

import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.OfferAlreadySubmittedException;
import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.ProductNotFoundException;
import bg.sofia.uni.fmi.mjt.shopping.portal.offer.Offer;
import jdk.jshell.spi.ExecutionControl;

import java.util.*;

public class ShoppingDirectoryImpl implements ShoppingDirectory {
    private static final int DAYS = 30;
    private final Map<String, SortedSet<Offer>> offers;

    public ShoppingDirectoryImpl() {
        this.offers = new HashMap<>();
    }

    /**
     * Returns a collection of offers submitted in the last 30 days
     * for the product with name @productName sorted by total price
     * in ascending order.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Collection<Offer> findAllOffers(String productName) throws IllegalArgumentException, ProductNotFoundException {
        if (productName == null) {
            throw new IllegalArgumentException();
        }

        if (!offers.containsKey(productName)) {
            throw new ProductNotFoundException();
        }

        // Offers must be sorted by price in ascending order
        Collection<Offer> offers = this.offers.get(productName);
        Set<Offer> submittedOffersInLastNDays = new LinkedHashSet<>();

        // Filter these offers which aren't submitted in the last N days
        for (Offer offer : offers) {
            if (offer.isSubmittedInLastNDays(DAYS)) {
                submittedOffersInLastNDays.add(offer);
            }
        }

        return submittedOffersInLastNDays;
    }

    /**
     * Returns the most favorable offer for the product with name @productName
     * submitted in the last 30 days - the one with lowest total price.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Offer findBestOffer(String productName) throws IllegalArgumentException, ProductNotFoundException {
        Collection<Offer> offersSubmittedInLastNDays = this.findAllOffers(productName);

        if (offersSubmittedInLastNDays.size() == 0) {
            throw new ProductNotFoundException();
        }

        return offersSubmittedInLastNDays.iterator().next();
    }

    /**
     * Returns a collection of price statistics for the product with name @productName
     * sorted by date in descending order.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Collection<PriceStatistic> collectProductStatistics(String productName) throws IllegalArgumentException, ProductNotFoundException {
        throw new UnsupportedOperationException();
    }

    /**
     * Submits a new offer.
     *
     * @throws OfferAlreadySubmittedException if an identical @offer has already been submitted
     * @throws IllegalArgumentException       if @offer is null
     */
    @Override
    public void submitOffer(Offer offer) throws IllegalArgumentException, OfferAlreadySubmittedException {
        if (offer == null) {
            throw new IllegalArgumentException();
        }

        String productName = offer.getProductName();
        SortedSet<Offer> offersForProduct = new TreeSet<>(new PriceComparator());
        if (this.offers.containsKey(productName)) {
            offersForProduct = this.offers.get(productName);
            if (offersForProduct.contains(offer)) {
                throw new OfferAlreadySubmittedException();
            }
        }

        offersForProduct.add(offer);
        this.offers.put(productName, offersForProduct);
    }
}
