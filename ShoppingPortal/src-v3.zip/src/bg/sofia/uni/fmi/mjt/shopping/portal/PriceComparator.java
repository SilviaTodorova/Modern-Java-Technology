package bg.sofia.uni.fmi.mjt.shopping.portal;

import bg.sofia.uni.fmi.mjt.shopping.portal.offer.Offer;

import java.util.*;

public class PriceComparator implements Comparator<Offer> {
    @Override
    public int compare(Offer o1, Offer o2) {
        if (o1.equals(o2)) {
            return 0;
        }

        // Ascending order
        double difference = o1.getTotalPrice() - o2.getTotalPrice();
        if (difference < 0) {
            return -1;
        } else if (difference > 0) {
            return 1;
        } else {
            return o1.compareTo(o2);
        }
    }
}

