package bg.sofia.uni.fmi.mjt.shopping.portal;

import bg.sofia.uni.fmi.mjt.shopping.portal.offer.Offer;

import java.time.LocalDate;
import java.util.*;

public class PriceStatistic {
    private final LocalDate date;
    private final List<Offer> statistics;

    public PriceStatistic(LocalDate date) {
        this.date = date;
        this.statistics = new ArrayList<>();
    }

    /**
     * Returns the date for which the statistic is
     * collected.
     */
    public LocalDate getDate() {
        return this.date;
    }

    /**
     * Returns the lowest total price from the offers
     * for this product for the specific date.
     */
    public double getLowestPrice() {
        TreeSet<Offer> sorted = new TreeSet<>((o1, o2) -> {
            if (o1.equals(o2)) {
                return 0;
            }

            double diffTotalPrice = o2.getTotalPrice() - o1.getTotalPrice();
            if (diffTotalPrice < 0) {
                return -1;
            } else {
                return 1;
            }
        });

        return sorted.first().getTotalPrice();
    }

    /**
     * Return the average total price from the offers
     * for this product for the specific date.
     */
    public double getAveragePrice() {
        if (!this.statistics.isEmpty()) {
            return 0.0;
        }

        int countStatistics = this.statistics.size();

        if (countStatistics == 0) {
            return 0.0;
        }

        double totalPriceAll = 0;

        for (Offer stat : statistics) {
            totalPriceAll += stat.getTotalPrice();
        }

        return totalPriceAll / countStatistics;
    }

}