package bg.sofia.uni.fmi.mjt.shopping.portal;

import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        LocalDate test = LocalDate.now().minusDays(1);
        System.out.println(test);
    }
}
