package bg.sofia.uni.fmi.mjt.shopping.portal;

import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.OfferAlreadySubmittedException;
import bg.sofia.uni.fmi.mjt.shopping.portal.exceptions.ProductNotFoundException;
import bg.sofia.uni.fmi.mjt.shopping.portal.offer.Offer;

import java.util.*;

public class ShoppingDirectoryImpl implements ShoppingDirectory {
    private static final int LAST_DAYS = 30;
    private final Map<String, List<Offer>> offers;
    private final Map<String, Set<PriceStatistic>> statistics;

    public ShoppingDirectoryImpl() {
        this.offers = new HashMap<>();
        this.statistics = new HashMap<>();
    }

    /**
     * Returns a collection of offers submitted in the last 30 days
     * for the product with name @productName sorted by total price
     * in ascending order.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Collection<Offer> findAllOffers(String productName) throws IllegalArgumentException, ProductNotFoundException {
        if (productName == null) {
            throw new IllegalArgumentException();
        }

        if (!offers.containsKey(productName)) {
            throw new ProductNotFoundException();
        }

        List<Offer> allOffers = this.offers.get(productName);

        // TODO: filter
        List<Offer> allOffersInLastNDays = allOffers.subList(0, LAST_DAYS);

        allOffersInLastNDays.sort(new PriceComparator());
        return allOffersInLastNDays;
    }

    /**
     * Returns the most favorable offer for the product with name @productName
     * submitted in the last 30 days - the one with lowest total price.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Offer findBestOffer(String productName) throws IllegalArgumentException, ProductNotFoundException {
        TreeSet<Offer> sorted = new TreeSet(this.findAllOffers(productName));
        return sorted.last();
    }

    /**
     * Returns a collection of price statistics for the product with name @productName
     * sorted by date in descending order.
     *
     * @throws ProductNotFoundException if there is no product with name @productName
     * @throws IllegalArgumentException if @productName is null
     */
    @Override
    public Collection<PriceStatistic> collectProductStatistics(String productName) throws IllegalArgumentException, ProductNotFoundException {
        if (productName == null) {
            throw new IllegalArgumentException();
        }

        if (!statistics.containsKey(productName)) {
            throw new ProductNotFoundException();
        }

        return this.statistics.get(productName);
    }

    /**
     * Submits a new offer.
     *
     * @throws OfferAlreadySubmittedException if an identical @offer has already been submitted
     * @throws IllegalArgumentException       if @offer is null
     */
    @Override
    public void submitOffer(Offer offer) throws IllegalArgumentException, OfferAlreadySubmittedException {
        if (offer == null) {
            throw new IllegalArgumentException();
        }

        String productName = offer.getProductName();
        if (!this.offers.containsKey(productName)) {
            throw new OfferAlreadySubmittedException();
        }

        List<Offer> allOffersForProduct = this.offers.get(productName);
        if (allOffersForProduct == null) {
            allOffersForProduct = new LinkedList<>();
        }

        if (allOffersForProduct.contains(offer)) {
            throw new OfferAlreadySubmittedException();
        }

        allOffersForProduct.add(offer);
        this.offers.put(offer.getProductName(), allOffersForProduct);
    }
}
