package bg.sofia.uni.fmi.mjt.shopping.portal;

import java.time.LocalDate;

public class PriceStatistic {
    private LocalDate date;
    private double averagePrice;
    private double lowerPrice;

    public PriceStatistic(LocalDate date, double averagePrice, double lowerPrice) {
        this.setDate(date);
        this.setAveragePrice(averagePrice);
        this.setLowerPrice(lowerPrice);
    }

    /**
     * Returns the date for which the statistic is
     * collected.
     */
    public LocalDate getDate() {
        return this.date;
    }

    /**
     * Returns the lowest total price from the offers
     * for this product for the specific date.
     */
    public double getLowestPrice() {
        return this.lowerPrice;
    }

    /**
     * Return the average total price from the offers
     * for this product for the specific date.
     */
    public double getAveragePrice() {
        return averagePrice;
    }

    public void setDate(LocalDate date) {
        if (date == null) {
            throw new IllegalArgumentException();
        }

        this.date = date;
    }

    public void setAveragePrice(double averagePrice) {
        if (averagePrice < 0) {
            throw new IllegalArgumentException();
        }

        this.averagePrice = averagePrice;
    }

    public void setLowerPrice(double lowerPrice) {
        if (lowerPrice < 0) {
            throw new IllegalArgumentException();
        }

        this.lowerPrice = lowerPrice;
    }
}