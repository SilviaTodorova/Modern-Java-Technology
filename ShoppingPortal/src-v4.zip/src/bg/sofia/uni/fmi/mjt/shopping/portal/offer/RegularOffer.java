package bg.sofia.uni.fmi.mjt.shopping.portal.offer;

import java.time.LocalDate;
import java.util.Objects;

public class RegularOffer extends AbstractOffer {
    public RegularOffer(String name, LocalDate date, String descr, double price, double shipping) {
        super(name, date, descr, price, shipping);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AbstractOffer other = (RegularOffer) o;

        String productName = this.getProductName();
        String productNameLowerCase = productName.toLowerCase();

        String otherProductName = other.getProductName();
        String otherProductNameLowerCase = otherProductName.toLowerCase();

        boolean equalsProductName = Objects.equals(productNameLowerCase, otherProductNameLowerCase);
        boolean equalsDate = Objects.equals(this.getDate(), other.getDate());
        boolean equalsTotal = Objects.equals(this.getTotalPrice(), other.getTotalPrice());

        return equalsProductName && equalsDate && equalsTotal;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.getProductName(), this.getDate(), this.getTotalPrice());
    }

    @Override
    public int compareTo(Offer o) {
        if (this.equals(o)) {
            return 0;
        }

        AbstractOffer other = (RegularOffer) o;

        // Descending order
        double difference = this.getDate().compareTo(other.getDate());
        if (difference < 0) {
            return 1;
        } else {
            return -1;
        }
    }
}
