package bg.sofia.uni.fmi.mjt.shopping.portal.offer;

import java.time.LocalDate;
import java.util.Objects;

public class RegularOffer extends AbstractOffer {
    public RegularOffer(String name, LocalDate date, String descr, double price, double shipping) {
        super(name, date, descr, price, shipping);
    }
}
