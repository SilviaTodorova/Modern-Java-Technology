package bg.sofia.uni.fmi.mjt.authroship.detection.models.contracts;

public interface PhraseAnalyzer {
    double getAverageCountPhrases();
}
