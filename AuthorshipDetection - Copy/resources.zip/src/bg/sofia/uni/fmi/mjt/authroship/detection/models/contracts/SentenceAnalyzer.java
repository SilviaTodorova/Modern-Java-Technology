package bg.sofia.uni.fmi.mjt.authroship.detection.models.contracts;

public interface SentenceAnalyzer {
    double getAverageCountWords();

    int getCountSentence();
}
