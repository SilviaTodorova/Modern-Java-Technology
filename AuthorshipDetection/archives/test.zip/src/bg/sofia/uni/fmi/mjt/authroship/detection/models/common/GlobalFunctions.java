package bg.sofia.uni.fmi.mjt.authroship.detection.models.common;

public final class GlobalFunctions {

    private GlobalFunctions() {
    }

    public static String cleanUp(String word) {
        String regex = "^[!.,:;\\-?<>#*\'\"\\[\\(\\]\\)\\n\\t\\\\]+|[!.,:;\\-?<>#\\*\'\"\\[\\(\\]\\)\\n\\t\\\\]+$";
        return word.toLowerCase()
                .replaceAll( regex, "");
    }
}
