package bg.sofia.uni.fmi.mjt.authroship.detection;

import bg.sofia.uni.fmi.mjt.authroship.detection.models.AuthorshipDetectorImpl;
import bg.sofia.uni.fmi.mjt.authroship.detection.models.LinguisticSignature;
import bg.sofia.uni.fmi.mjt.authroship.detection.models.common.enums.FeatureType;
import bg.sofia.uni.fmi.mjt.authroship.detection.models.contracts.AuthorshipDetector;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.EnumMap;
import java.util.Map;
import java.io.FileNotFoundException;

import static bg.sofia.uni.fmi.mjt.authroship.detection.models.common.GlobalConstants.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class AuthorshipDetectorTest {
    public static final String AUTHOR_OF_MYSTERY = "Douglas Adams";
    public static final String AUTHOR_OF_MYSTERY_1 = "Jane Austen";
    public static final String AUTHOR_OF_MYSTERY_2 = "Charles Dodgson";
    public static final String AUTHOR_OF_MYSTERY_3 = "Charles Dickens";
    public static final String AUTHOR_OF_MYSTERY_4 = "Agatha Christie";
    public static final String AUTHOR_OF_MYSTERY_5 = "Brothers Grim";

    private static final double[] WEIGHTS = new double[]{11, 33, 50, 0.4, 4};
    private static final double WEIGHT_1 = 4.41553119311;
    private static final double WEIGHT_2 = 0.0563451817574;
    private static final double WEIGHT_3 = 0.02229943808;
    private static final double WEIGHT_4 = 16.8869087498;
    private static final double WEIGHT_5 = 2.54817097682;

    private static final double WEIGHT_6 = 4.40212537354;
    private static final double WEIGHT_7 = 0.103719383127;
    private static final double WEIGHT_8 = 0.0534892315963;
    private static final double WEIGHT_9 = 10.0836888743;
    private static final double WEIGHT_10 = 1.90662947161;

    public static double[] signatureJnAusten;
    public static double[] signatureAgChristie;

    private static LinguisticSignature janeAustenSignature;
    private static LinguisticSignature agathaChristieSignature;

    public static String fileNameKnownSignatures;
    public static String fileNameWithAbsolutePathMystery1;
    public static String fileNameWithAbsolutePathMystery2;
    public static String fileNameWithAbsolutePathMystery3;
    public static String fileNameWithAbsolutePathMystery4;
    public static String fileNameWithAbsolutePathMystery5;

    @BeforeClass
    public static void setUp() throws FileNotFoundException {
        String pathToProject = Paths.get(EMPTY_STRING).toAbsolutePath().toString();
        fileNameKnownSignatures = Paths.get(
                pathToProject,
                FOLDER_RESOURCES,
                FOLDER_KNOWN_SIGNATURES,
                FILE_KNOWN_SIGNATURES
        ).toString();

        fileNameWithAbsolutePathMystery1 = Paths.get(pathToProject,
                FOLDER_RESOURCES,
                FOLDER_MYSTERY_FILES,
                FILE_NAME_MYSTERY_1
        ).toString();

        fileNameWithAbsolutePathMystery2 = Paths.get(pathToProject,
                FOLDER_RESOURCES,
                FOLDER_MYSTERY_FILES,
                FILE_NAME_MYSTERY_2
        ).toString();

        fileNameWithAbsolutePathMystery3 = Paths.get(pathToProject,
                FOLDER_RESOURCES,
                FOLDER_MYSTERY_FILES,
                FILE_NAME_MYSTERY_3
        ).toString();

        fileNameWithAbsolutePathMystery4 = Paths.get(pathToProject,
                FOLDER_RESOURCES,
                FOLDER_MYSTERY_FILES,
                FILE_NAME_MYSTERY_4
        ).toString();

        fileNameWithAbsolutePathMystery5 = Paths.get(pathToProject,
                FOLDER_RESOURCES,
                FOLDER_MYSTERY_FILES,
                FILE_NAME_MYSTERY_5
        ).toString();

        signatureJnAusten = new double[]{WEIGHT_1, WEIGHT_2, WEIGHT_3, WEIGHT_4, WEIGHT_5};
        signatureAgChristie = new double[]{WEIGHT_6, WEIGHT_7, WEIGHT_8, WEIGHT_9, WEIGHT_10};

        janeAustenSignature = createSignature(signatureJnAusten);
        agathaChristieSignature = createSignature(signatureAgChristie);
    }

    private static LinguisticSignature createSignature(double[] signatures) {
        Map<FeatureType, Double> features = new EnumMap<>(FeatureType.class);

        FeatureType[] values = FeatureType.values();
        for (int index = 0; index < COUNT_FEATURES; index++) {
            features.put(values[index], signatures[index]);
        }

        return new LinguisticSignature(features);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateInstanceOfAuthorshipDetectorImplWithInvalidArgumentsThrowsIllegalArgumentException() {
        AuthorshipDetector detector = new AuthorshipDetectorImpl(null, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateInstanceOfAuthorshipDetectorImplWithNegativeWeightsThrowsIllegalArgumentException()
            throws FileNotFoundException {
        double[] negativeWeights = new double[]{-11, 33, 50, 0.4, 4};
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector detector = new AuthorshipDetectorImpl(signaturesDataset, negativeWeights);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateInstanceOfAuthorshipDetectorImplWithMoreFeathersThrowsIllegalArgumentException()
            throws FileNotFoundException {
        double[] moreWeights = new double[]{00, 11, 33, 50, 0.4, 4};
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector detector = new AuthorshipDetectorImpl(signaturesDataset, moreWeights);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCreateInstanceOfLinguisticSignatureWithInvalidArgumentsThrowsIllegalArgumentException() {
        LinguisticSignature signature = new LinguisticSignature(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCalculateSimilarityWithInvalidArgumentsThrowsIllegalArgumentException()
            throws FileNotFoundException {
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
        authorshipDetector.calculateSimilarity(null, null);
    }

    @Test
    public void testCalculateSimilarityWithTwoIdenticalSignatures() throws IOException {
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);

        double value = authorshipDetector.calculateSimilarity(janeAustenSignature, janeAustenSignature);
        assertEquals("Similarity between two identical signatures must be 0", 0, value, DELTA);
    }

    @Test
    public void testCalculateSimilarityWithTwoDifferentSignatures() throws IOException {
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
        double value = authorshipDetector.calculateSimilarity(janeAustenSignature, agathaChristieSignature);
        assertNotEquals("Similarity between two different signatures can't be 0", 0, value, DELTA);
    }

    @Test
    public void testCalculateSimilarity() throws IOException {
        double first[] = new double[]{4.4, 0.1, 0.05, 10, 2};
        double second[] = new double[]{4.3, 0.1, 0.04, 16, 4};

        LinguisticSignature firstSignature = createSignature(first);
        LinguisticSignature secondSignature = createSignature(second);

        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);

        double value = authorshipDetector.calculateSimilarity(firstSignature, secondSignature);
        assertEquals("Similarity must be 12", 12, value, DELTA);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFindAuthorWithInvalidArgumentThrowsIllegalArgumentException() throws IOException {
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
        authorshipDetector.findAuthor(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testCalculateSignatureWithInvalidArgumentThrowsIllegalArgumentException() throws IOException {
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
        authorshipDetector.calculateSignature(null);
    }

    @Test
    public void testFindAuthorOfMystery1() throws IOException {
        InputStream stream = new FileInputStream(fileNameWithAbsolutePathMystery1);
        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
        String author = authorshipDetector.findAuthor(stream);
        String message = String.format("Author of file: %s must be %s", FILE_NAME_MYSTERY_1, AUTHOR_OF_MYSTERY_1);
        assertEquals(message, AUTHOR_OF_MYSTERY, author);
    }

//    @Test
//    public void testFindAuthorOfMystery2() throws IOException {
//        InputStream stream = new FileInputStream(fileNameWithAbsolutePathMystery2);
//        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
//        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
//        String author = authorshipDetector.findAuthor(stream);
//        String message = String.format("Author of file: %s must be %s", FILE_NAME_MYSTERY_2, AUTHOR_OF_MYSTERY_2);
//        assertEquals(message, AUTHOR_OF_MYSTERY_2, author);
//    }
//
//    @Test
//    public void testFindAuthorOfMystery3() throws IOException {
//        InputStream stream = new FileInputStream(fileNameWithAbsolutePathMystery3);
//        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
//        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
//        String author = authorshipDetector.findAuthor(stream);
//        String message = String.format("Author of file: %s must be %s", FILE_NAME_MYSTERY_3, AUTHOR_OF_MYSTERY_3);
//        assertEquals(message, AUTHOR_OF_MYSTERY_3, author);
//    }
//
//    @Test
//    public void testFindAuthorOfMystery4() throws IOException {
//        InputStream stream = new FileInputStream(fileNameWithAbsolutePathMystery4);
//        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
//        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
//        String author = authorshipDetector.findAuthor(stream);
//        String message = String.format("Author of file: %s must be %s", FILE_NAME_MYSTERY_4, AUTHOR_OF_MYSTERY_4);
//        assertEquals(message, AUTHOR_OF_MYSTERY_4, author);
//    }
//
//    @Test
//    public void testFindAuthorOfMystery5() throws IOException {
//        InputStream stream = new FileInputStream(fileNameWithAbsolutePathMystery5);
//        InputStream signaturesDataset = new FileInputStream(new File(fileNameKnownSignatures));
//        AuthorshipDetector authorshipDetector = new AuthorshipDetectorImpl(signaturesDataset, WEIGHTS);
//        String author = authorshipDetector.findAuthor(stream);
//        String message = String.format("Author of file: %s must be %s", FILE_NAME_MYSTERY_5, AUTHOR_OF_MYSTERY_5);
//        assertEquals(message, AUTHOR_OF_MYSTERY_5, author);
//    }
}
